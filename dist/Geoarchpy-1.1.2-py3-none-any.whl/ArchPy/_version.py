# Version

# major, minor, micro
version_info = (1, 1, 2)

__version__ = '.'.join(map(str, version_info))